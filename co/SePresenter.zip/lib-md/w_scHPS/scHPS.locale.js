/** SCENARI Html Presentation System - Localisations */
/*00*/ scHPS.fStrings =     ["Précédent","Précédent (flèche gauche)",
/*02*/                       "Suivant","Suivant (flèche droite)",
/*04*/                       "Fermer","Fermer le zoom (ESC)",
/*06*/                       "ATTENTION : L\'extension Firebug est active.\nIl est conseillé de désactiver Firebug pour visualiser ce diaporama.","ATTENTION : Ce diaporama n\'est pas compatible avec cette version de Internet Explorer.\nVeuillez utiliser un navigateur plus récent.",
/*08*/                       "Mode HTML","Basculer en mode HTML simple (H)",
/*10*/                       "Etes-vous sûr de vouloir basculer vers une version HTML simple de ce diaporama ?","Effets",
/*12*/                       "Activer les effets visuels (F)","Désactiver les effets visuels (F)",
/*14*/                       "précédent","image précédente",
/*16*/                       "suivant","image suivante",
/*18*/                       "lancer","lancer l\'animation",
/*20*/                       "arrêter","arrêter l\'animation",
/*22*/                       "chargement en cours...","Les restrictions sécuritaires de votre navigateur interdisent l\'utilisation du mode diaporama.\n\nVoulez-vous basculer vers une version HTML simple ?"];

