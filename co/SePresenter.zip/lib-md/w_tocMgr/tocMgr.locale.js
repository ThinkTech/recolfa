/* Localisations */
tocMgr.fStrings = ["menu","",
	            "Cacher le menu (touche M)","Afficher le menu (touche M)",
	            "défilement haut","Faire défiler le menu vers le haut",
	            "défilement bas","Faire défiler le menu vers le bas"];

